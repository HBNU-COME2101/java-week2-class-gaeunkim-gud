package week2_class_20232541;

import java.util.Scanner;

public class Chapter1_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("생일 입력 하세요>>");
		int birth = scanner.nextInt();
		
		int year = birth / 10000;
		int month = (birth/100) % 100;
		int day = birth %100;
		
		System.out.print(year+ "년 " + month + "월 " + day +"일" );
		
		scanner.close();//

	}

}
