package week2_class_20232541;

public class Chapter1_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("20232541 김가은");
		


	}

}
