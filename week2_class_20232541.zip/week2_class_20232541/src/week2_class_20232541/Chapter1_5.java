package week2_class_20232541;

import java.util.Scanner;

public class Chapter1_5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
Scanner scanner = new Scanner(System.in);
		
		System.out.print("나이를 입력하세요");
		int birth = scanner.nextInt();
		int red = birth/10;
		int blue = (birth%10)/5;
		int yellow= birth%5;
		
		if(birth<=0) {
			System.out.print("나이는 양수로만 입력하세요");
		}
		else {
			System.out.print("빨간초 " + red + "개 파란초 " + blue +"개 노란초" + yellow + "개가 필요합니다" );
		}
	
		
		scanner.close();//

	}

}
