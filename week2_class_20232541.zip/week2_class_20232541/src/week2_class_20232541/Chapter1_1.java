package week2_class_20232541;

public class Chapter1_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.print("Hello world!.");

	}

}
