package week2_class_20232541;

import java.util.Scanner;

public class Chapter1_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
Scanner scanner = new Scanner(System.in);
		
		System.out.print("여행지");
		String trip = scanner.nextLine();
		System.out.print("인원수");
		int people = scanner.nextInt();
		System.out.print("숙박일");
		int aud = scanner.nextInt();
		System.out.print("1인당 항공료");
		int air = scanner.nextInt();
		System.out.print("1방 숙박비");
		int money = scanner.nextInt();
		
		int roomcount=(people+1)/2;
		int result= people*air+roomcount*money*aud;
		
		
		System.out.print(people + "명의 " + trip +" "+ aud +"박"+ (aud+1)+"일 여행에는 " + roomcount + "개 필요하며 경비는" + result + " 원입니다");
		
		scanner.close();//
		

	}

}
